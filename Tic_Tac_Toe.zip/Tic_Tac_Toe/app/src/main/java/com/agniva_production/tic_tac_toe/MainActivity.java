package com.agniva_production.tic_tac_toe;


import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, Button.OnTouchListener {


    String[] tic_tac_toe;
    String name1, name2;
    Button but1, but2, but3, but4, but5, but6, but7, but8, but9;
    TextView caption;
    int numberOfTerms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberOfTerms = 0;
        caption = findViewById(R.id.lblCaption);
        but1 = findViewById(R.id.but1);
        but2 = findViewById(R.id.but2);
        but3 = findViewById(R.id.but3);
        but4 = findViewById(R.id.but4);
        but5 = findViewById(R.id.but5);
        but6 = findViewById(R.id.but6);
        but7 = findViewById(R.id.but7);
        but8 = findViewById(R.id.but8);
        but9 = findViewById(R.id.but9);

        but1.setOnClickListener(this);
        but2.setOnClickListener(this);
        but3.setOnClickListener(this);
        but4.setOnClickListener(this);
        but5.setOnClickListener(this);
        but6.setOnClickListener(this);
        but7.setOnClickListener(this);
        but8.setOnClickListener(this);
        but9.setOnClickListener(this);

        but1.setOnTouchListener(this);
        but2.setOnTouchListener(this);
        but3.setOnTouchListener(this);
        but4.setOnTouchListener(this);
        but5.setOnTouchListener(this);
        but6.setOnTouchListener(this);
        but7.setOnTouchListener(this);
        but8.setOnTouchListener(this);
        but9.setOnTouchListener(this);



        tic_tac_toe = new String[9];
        for(int i=0; i<9; i++)
            tic_tac_toe[i] = "   ";
        printTheBoard();

        AlertDialog.Builder ab1 = new AlertDialog.Builder(MainActivity.this);
        ab1.setTitle("Please enter the name of second player (For O)");
        final EditText et1 = new EditText(MainActivity.this);
        et1.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        ab1.setView(et1);
        ab1.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = et1.getText().toString().trim();
                if(name.equals("")){
                    name2 = "Player1";
                }
                else{
                    name2 = name;
                }
            }
        });
        ab1.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                name2 = "Player2";
                //Toast.makeText(getApplicationContext(), name2, Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog a1 = ab1.create();
        a1.show();

        AlertDialog.Builder ab2 = new AlertDialog.Builder(MainActivity.this);
        ab2.setTitle("Please enter the name of first player (For X)");
        final EditText et2 = new EditText(MainActivity.this);
        et2.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        ab2.setView(et2);
        ab2.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = et2.getText().toString().trim();
                if(name.equals("")){
                    name1 = "Player1";
                }
                else{
                    name1 = name;
                }
                caption.append("\nIts "+name1+"'s term");
            }
        });
        ab2.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                name1 = "Player1";
                //Toast.makeText(getApplicationContext(), name1, Toast.LENGTH_SHORT).show();
                caption.append("\nIts "+name1+"'s term");
            }
        });
        AlertDialog a2 = ab2.create();
        a2.show();
    }

    private void printTheBoard() {
        but1.setText(tic_tac_toe[0]);
        but2.setText(tic_tac_toe[1]);
        but3.setText(tic_tac_toe[2]);
        but4.setText(tic_tac_toe[3]);
        but5.setText(tic_tac_toe[4]);
        but6.setText(tic_tac_toe[5]);
        but7.setText(tic_tac_toe[6]);
        but8.setText(tic_tac_toe[7]);
        but9.setText(tic_tac_toe[8]);
    }

    @Override
    public void onClick(View v) {
        Intent t = new Intent(getApplicationContext(), ButtonMusic.class);
        t.putExtra("Type", 0);
        stopService(t);
        startService(t);
        switch(v.getId()){
            case R.id.but1:execute(0);
                           break;
            case R.id.but2:execute(1);
                           break;
            case R.id.but3:execute(2);
                           break;
            case R.id.but4:execute(3);
                           break;
            case R.id.but5:execute(4);
                           break;
            case R.id.but6:execute(5);
                           break;
            case R.id.but7:execute(6);
                           break;
            case R.id.but8:execute(7);
                           break;
            case R.id.but9:execute(8);
                           break;
        }
    }

    private void execute(int i) {
        Button button;
        //Toast.makeText(getApplicationContext(), "Clicked on"+(i+1), Toast.LENGTH_SHORT).show();
        switch(i){
            case 0:button = findViewById(R.id.but1);
                   break;
            case 1:button = findViewById(R.id.but2);
                   break;
            case 2:button = findViewById(R.id.but3);
                   break;
            case 3:button = findViewById(R.id.but4);
                   break;
            case 4:button = findViewById(R.id.but5);
                   break;
            case 5:button = findViewById(R.id.but6);
                   break;
            case 6:button = findViewById(R.id.but7);
                   break;
            case 7:button = findViewById(R.id.but8);
                   break;
            case 8:button = findViewById(R.id.but9);
                   break;
            default:return;
        }
        button.setEnabled(false);

        if(numberOfTerms%2 == 0){
            caption.setText("ITS\n"+name2+"'s\nTURN.\n");
            tic_tac_toe[i] = " X ";
            printTheBoard();
        }
        else{
            caption.setText("ITS\n"+name1+"'s\nTURN.\n");
            tic_tac_toe[i] = " O ";
            printTheBoard();
        }
        numberOfTerms++;
        int check = checkCondition();
        String msg;
        if(check == 1){
            msg = "CONGRATULATION\n"+name1+"\nHAS WON THE GAME";
            caption.setText(msg);
            Intent t = new Intent(getApplicationContext(), ButtonMusic.class);
            t.putExtra("Type", 1);
            stopService(t);
            startService(t);
            end();
            alert(msg, name1+" Wins");
        }
        else if(check == 2){
            msg = "CONGRATULATION\n"+name2+"\nHAS WON THE GAME";
            caption.setText(msg);
            Intent t = new Intent(getApplicationContext(), ButtonMusic.class);
            t.putExtra("Type", 1);
            stopService(t);
            startService(t);
            end();
            alert(msg, name2+" Wins");
        }
        else if(check == 3){
            msg = "MATCH DRAW";
            caption.setText(msg);
            alert(msg, "Match Draw");
        }
    }

    private void alert(String msg, String name) {
        AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
        ab.setTitle(name);
        TextView tv = new TextView(getApplicationContext());
        tv.setText(msg+"\nPlease RESET from menu");
        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        tv.setTextSize(20);
        ab.setView(tv);
        ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        ab.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {

            }
        });
        AlertDialog a = ab.create();
        a.show();
    }

    private void end() {
        but1.setEnabled(false);
        but2.setEnabled(false);
        but3.setEnabled(false);
        but4.setEnabled(false);
        but5.setEnabled(false);
        but6.setEnabled(false);
        but7.setEnabled(false);
        but8.setEnabled(false);
        but9.setEnabled(false);
    }

    private int checkCondition() {
        if(tic_tac_toe[0].equals(tic_tac_toe[1]) && tic_tac_toe[1].equals(tic_tac_toe[2])){
            if(tic_tac_toe[0] != "   ")  changeColor(but1, but2, but3);
            if(tic_tac_toe[0].equals(" X "))
                return 1;
            else if(tic_tac_toe[0].equals(" O "))
                return 2;
        }
        if(tic_tac_toe[3].equals(tic_tac_toe[4]) && tic_tac_toe[4].equals(tic_tac_toe[5])){
            if(tic_tac_toe[3] != "   ")  changeColor(but4, but5, but6);
            if(tic_tac_toe[3].equals(" X "))
                return 1;
            else if(tic_tac_toe[3].equals(" O "))
                return 2;
        }
        if(tic_tac_toe[6].equals(tic_tac_toe[7]) && tic_tac_toe[7].equals(tic_tac_toe[8])){
            if(tic_tac_toe[6] != "   ")  changeColor(but7, but8, but9);
            if(tic_tac_toe[6].equals(" X "))
                return 1;
            else if(tic_tac_toe[6].equals(" O "))
                return 2;
        }
        if(tic_tac_toe[0].equals(tic_tac_toe[3]) && tic_tac_toe[3].equals(tic_tac_toe[6])){
            if(tic_tac_toe[0] != "   ")  changeColor(but1, but4, but7);
            if(tic_tac_toe[0].equals(" X "))
                return 1;
            else if(tic_tac_toe[0].equals(" O "))
                return 2;
        }
        if(tic_tac_toe[1].equals(tic_tac_toe[4]) && tic_tac_toe[4].equals(tic_tac_toe[7])){
            if(tic_tac_toe[1] != "   ")  changeColor(but2, but5, but8);
            if(tic_tac_toe[1].equals(" X "))
                return 1;
            else if(tic_tac_toe[1].equals(" O "))
                return 2;
        }
        if(tic_tac_toe[2].equals(tic_tac_toe[5]) && tic_tac_toe[5].equals(tic_tac_toe[8])){
            if(tic_tac_toe[2] != "   ")  changeColor(but3, but6, but9);
            if(tic_tac_toe[2].equals(" X "))
                return 1;
            else if(tic_tac_toe[2].equals(" O "))
                return 2;
        }
        if(tic_tac_toe[0].equals(tic_tac_toe[4]) && tic_tac_toe[4].equals(tic_tac_toe[8])){
            if(tic_tac_toe[0] != "   ")  changeColor(but1, but5, but9);
            if(tic_tac_toe[0].equals(" X "))
                return 1;
            else if(tic_tac_toe[0].equals(" O "))
                return 2;
        }
        if(tic_tac_toe[2].equals(tic_tac_toe[4]) && tic_tac_toe[4].equals(tic_tac_toe[6])){
            if(tic_tac_toe[2] != "   ")  changeColor(but3, but5, but7);
            if(tic_tac_toe[2].equals(" X "))
                return 1;
            else if(tic_tac_toe[2].equals(" O "))
                return 2;
        }
        if(numberOfTerms == 9){
            return 3;
        }
        return 0;
    }

    private void changeColor(Button but1, Button but2, Button but3) {
        but1.setBackgroundResource(R.drawable.button_end);
        but2.setBackgroundResource(R.drawable.button_end);
        but3.setBackgroundResource(R.drawable.button_end);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.reset){
            for(int i=0; i<9; i++)
                tic_tac_toe[i] = "   ";
            printTheBoard();
            numberOfTerms = 0;
            caption.setText(R.string.caption_default);
            caption.append("\nIts "+name1+"'s term");
            but1.setEnabled(true);
            but2.setEnabled(true);
            but3.setEnabled(true);
            but4.setEnabled(true);
            but5.setEnabled(true);
            but6.setEnabled(true);
            but7.setEnabled(true);
            but8.setEnabled(true);
            but9.setEnabled(true);

            but1.setBackgroundResource(R.drawable.button_bg);
            but2.setBackgroundResource(R.drawable.button_bg);
            but3.setBackgroundResource(R.drawable.button_bg);
            but4.setBackgroundResource(R.drawable.button_bg);
            but5.setBackgroundResource(R.drawable.button_bg);
            but6.setBackgroundResource(R.drawable.button_bg);
            but7.setBackgroundResource(R.drawable.button_bg);
            but8.setBackgroundResource(R.drawable.button_bg);
            but9.setBackgroundResource(R.drawable.button_bg);
        }
        else if(item.getItemId() == R.id.change1){
            AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
            ab.setTitle("ENTER THE NEW NAME OF FIRST PLAYER (FOR X)");
            final EditText et = new EditText(MainActivity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String name = et.getText().toString().trim();
                    if(name.equals("")){
                        //Nothing happens, name remains same.
                    }
                    else{
                        name1 = name;
                        if(numberOfTerms%2 == 0){
                            caption.setText(R.string.caption_default);
                            caption.append("\nIts "+name1+"'s term");
                        }
                    }
                }
            });
            ab.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    //Nothing happens, name remains same.
                }
            });
            AlertDialog a = ab.create();
            a.show();
        }
        else if(item.getItemId() == R.id.change2){
            AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
            ab.setTitle("ENTER THE NEW NAME OF SECOND PLAYER (FOR O)");
            final EditText et = new EditText(MainActivity.this);
            et.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            ab.setView(et);
            ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String name = et.getText().toString().trim();
                    if(name.equals("")){
                        //Nothing happens, name remains same.
                    }
                    else{
                        name2 = name;
                        if(numberOfTerms%2 != 0){
                            caption.setText("ITS\n"+name2+"'s\nTURN.\n");
                        }
                    }
                }
            });
            ab.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    //Nothing happens, name remains same.
                }
            });
            AlertDialog a = ab.create();
            a.show();
        }
        else if(item.getItemId() == R.id.exit){
            exit();
        }
        else if(item.getItemId() == R.id.about){
            startActivity(new Intent(MainActivity.this, AboutActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

    protected void exit(){
        AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
        ab.setTitle("GOOD BYE");
        TextView tv = new TextView(getApplicationContext());
        tv.setText("Good buy User.\nThank you for using our application.");
        tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        tv.setTextSize(20);
        ab.setView(tv);
        ab.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        ab.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {

            }
        });
        AlertDialog a = ab.create();
        a.show();
    }

    @Override
    public void onBackPressed() {
        exit();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        Button button = findViewById(v.getId());
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:
                button.setBackgroundResource(R.drawable.button_bg_click);
                break;
            case MotionEvent.ACTION_UP:
                button.setBackgroundResource(R.drawable.button_bg);
                return false;
        }
        return false;
    }
}
